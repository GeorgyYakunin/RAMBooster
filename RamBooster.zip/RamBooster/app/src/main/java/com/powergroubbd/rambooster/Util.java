package com.powergroubbd.rambooster;

/**
 * Created by Osman Goni Nahid on 11/3/2015.
 */
public class Util {
    public static final String MyPREFERENCES = "RamBoosterPref";
    public static final String KEY_STATUS = "status";
}
